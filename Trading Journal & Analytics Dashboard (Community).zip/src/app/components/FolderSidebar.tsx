import { useState } from 'react';
import { Folder as FolderType } from '../types/trading';
import { FolderOpen, Plus, Edit2, Trash2, Download, Upload, X } from 'lucide-react';

interface FolderSidebarProps {
  folders: FolderType[];
  selectedFolderId: string | null;
  onSelectFolder: (id: string) => void;
  onAddFolder: (folder: Omit<FolderType, 'id' | 'createdAt'>) => void;
  onEditFolder: (id: string, folder: Partial<FolderType>) => void;
  onDeleteFolder: (id: string) => void;
  onExport: (folderId: string) => void;
  onImport: () => void;
}

const COLORS = [
  '#EF4444', '#F59E0B', '#10B981', '#3B82F6', '#8B5CF6',
  '#EC4899', '#14B8A6', '#F97316', '#06B6D4', '#6366F1'
];

export function FolderSidebar({
  folders,
  selectedFolderId,
  onSelectFolder,
  onAddFolder,
  onEditFolder,
  onDeleteFolder,
  onExport,
  onImport,
}: FolderSidebarProps) {
  const [isAddingFolder, setIsAddingFolder] = useState(false);
  const [editingFolderId, setEditingFolderId] = useState<string | null>(null);
  const [folderForm, setFolderForm] = useState({
    name: '',
    color: COLORS[0],
    description: '',
    initialCapital: 100000,
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!folderForm.name.trim()) return;

    if (editingFolderId) {
      onEditFolder(editingFolderId, folderForm);
      setEditingFolderId(null);
    } else {
      onAddFolder(folderForm);
      setIsAddingFolder(false);
    }
    
    setFolderForm({
      name: '',
      color: COLORS[0],
      description: '',
      initialCapital: 100000,
    });
  };

  const startEdit = (folder: FolderType) => {
    setEditingFolderId(folder.id);
    setFolderForm({
      name: folder.name,
      color: folder.color,
      description: folder.description || '',
      initialCapital: folder.initialCapital,
    });
    setIsAddingFolder(true);
  };

  return (
    <div className="w-64 bg-gray-900 border-r border-gray-800 p-4 flex flex-col h-screen">
      <div className="flex items-center justify-between mb-6">
        <h2 className="font-semibold text-white">Portfolios</h2>
        <button
          onClick={() => setIsAddingFolder(true)}
          className="p-1 hover:bg-gray-800 rounded"
        >
          <Plus className="w-5 h-5 text-gray-400" />
        </button>
      </div>

      {isAddingFolder && (
        <div className="mb-4 p-3 bg-gray-800 rounded-lg">
          <form onSubmit={handleSubmit}>
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm text-gray-400">
                {editingFolderId ? 'Edit Portfolio' : 'New Portfolio'}
              </span>
              <button
                type="button"
                onClick={() => {
                  setIsAddingFolder(false);
                  setEditingFolderId(null);
                  setFolderForm({
                    name: '',
                    color: COLORS[0],
                    description: '',
                    initialCapital: 100000,
                  });
                }}
                className="text-gray-500 hover:text-gray-300"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <input
              type="text"
              placeholder="Portfolio Name"
              value={folderForm.name}
              onChange={(e) => setFolderForm({ ...folderForm, name: e.target.value })}
              className="w-full px-2 py-1 bg-gray-700 text-white rounded mb-2 text-sm"
              autoFocus
            />
            <input
              type="number"
              placeholder="Initial Capital"
              value={folderForm.initialCapital}
              onChange={(e) => setFolderForm({ ...folderForm, initialCapital: Number(e.target.value) })}
              className="w-full px-2 py-1 bg-gray-700 text-white rounded mb-2 text-sm"
            />
            <div className="flex gap-1 mb-2 flex-wrap">
              {COLORS.map((color) => (
                <button
                  key={color}
                  type="button"
                  onClick={() => setFolderForm({ ...folderForm, color })}
                  className={`w-6 h-6 rounded ${folderForm.color === color ? 'ring-2 ring-white' : ''}`}
                  style={{ backgroundColor: color }}
                />
              ))}
            </div>
            <button
              type="submit"
              className="w-full px-2 py-1 bg-blue-600 text-white rounded text-sm hover:bg-blue-700"
            >
              {editingFolderId ? 'Update' : 'Create'}
            </button>
          </form>
        </div>
      )}

      <div className="flex-1 overflow-y-auto space-y-2">
        {folders.map((folder) => (
          <div
            key={folder.id}
            onClick={() => onSelectFolder(folder.id)}
            className={`p-3 rounded-lg cursor-pointer group ${
              selectedFolderId === folder.id ? 'bg-gray-800' : 'hover:bg-gray-800/50'
            }`}
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 flex-1">
                <div
                  className="w-3 h-3 rounded-full"
                  style={{ backgroundColor: folder.color }}
                />
                <span className="text-sm text-white truncate">{folder.name}</span>
              </div>
              <div className="flex gap-1 opacity-0 group-hover:opacity-100">
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    onExport(folder.id);
                  }}
                  className="p-1 hover:bg-gray-700 rounded"
                >
                  <Download className="w-3 h-3 text-gray-400" />
                </button>
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    startEdit(folder);
                  }}
                  className="p-1 hover:bg-gray-700 rounded"
                >
                  <Edit2 className="w-3 h-3 text-gray-400" />
                </button>
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    if (confirm('Delete this portfolio?')) {
                      onDeleteFolder(folder.id);
                    }
                  }}
                  className="p-1 hover:bg-gray-700 rounded"
                >
                  <Trash2 className="w-3 h-3 text-red-400" />
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="mt-4 pt-4 border-t border-gray-800">
        <button
          onClick={onImport}
          className="w-full flex items-center justify-center gap-2 px-3 py-2 bg-gray-800 hover:bg-gray-700 rounded text-sm text-gray-300"
        >
          <Upload className="w-4 h-4" />
          Import Data
        </button>
      </div>
    </div>
  );
}
