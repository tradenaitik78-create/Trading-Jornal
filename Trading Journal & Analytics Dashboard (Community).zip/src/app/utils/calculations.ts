import { Trade, Analytics } from '../types/trading';

export function calculatePnL(trade: Trade): number {
  if (!trade.exitPrice) return 0;
  
  const diff = trade.tradeType === 'long' 
    ? (trade.exitPrice - trade.entryPrice) 
    : (trade.entryPrice - trade.exitPrice);
  
  return diff * trade.quantity;
}

export function calculateRiskReward(trade: Trade): number | undefined {
  if (!trade.target || !trade.stopLoss) return undefined;
  
  const risk = Math.abs(trade.entryPrice - trade.stopLoss);
  const reward = Math.abs(trade.target - trade.entryPrice);
  
  return risk > 0 ? reward / risk : 0;
}

export function calculateAnalytics(trades: Trade[], initialCapital: number): Analytics {
  const completedTrades = trades.filter(t => t.exitPrice !== undefined && t.exitPrice !== null);
  
  if (completedTrades.length === 0) {
    return {
      totalTrades: 0,
      winRate: 0,
      totalPnL: 0,
      bestTrade: 0,
      worstTrade: 0,
      avgWin: 0,
      avgLoss: 0,
      profitFactor: 0,
      expectancy: 0,
      maxConsecutiveWins: 0,
      maxConsecutiveLosses: 0,
      maxDrawdown: 0,
      sharpeRatio: 0,
      currentStreak: 0,
      roi: 0,
    };
  }
  
  const pnls = completedTrades.map(t => calculatePnL(t));
  const wins = pnls.filter(p => p > 0);
  const losses = pnls.filter(p => p < 0);
  
  const totalPnL = pnls.reduce((sum, p) => sum + p, 0);
  const totalWins = wins.reduce((sum, p) => sum + p, 0);
  const totalLosses = Math.abs(losses.reduce((sum, p) => sum + p, 0));
  
  const winRate = (wins.length / completedTrades.length) * 100;
  const avgWin = wins.length > 0 ? totalWins / wins.length : 0;
  const avgLoss = losses.length > 0 ? totalLosses / losses.length : 0;
  const profitFactor = totalLosses > 0 ? totalWins / totalLosses : totalWins;
  const expectancy = (winRate / 100) * avgWin - ((100 - winRate) / 100) * avgLoss;
  
  // Max consecutive wins/losses
  let maxConsecutiveWins = 0;
  let maxConsecutiveLosses = 0;
  let currentWinStreak = 0;
  let currentLossStreak = 0;
  
  pnls.forEach(pnl => {
    if (pnl > 0) {
      currentWinStreak++;
      currentLossStreak = 0;
      maxConsecutiveWins = Math.max(maxConsecutiveWins, currentWinStreak);
    } else {
      currentLossStreak++;
      currentWinStreak = 0;
      maxConsecutiveLosses = Math.max(maxConsecutiveLosses, currentLossStreak);
    }
  });
  
  // Current streak
  const lastTradePnL = pnls[pnls.length - 1];
  let currentStreak = 0;
  for (let i = pnls.length - 1; i >= 0; i--) {
    if ((lastTradePnL > 0 && pnls[i] > 0) || (lastTradePnL <= 0 && pnls[i] <= 0)) {
      currentStreak++;
    } else {
      break;
    }
  }
  if (lastTradePnL <= 0) currentStreak = -currentStreak;
  
  // Max drawdown
  let peak = initialCapital;
  let maxDrawdown = 0;
  let runningCapital = initialCapital;
  
  pnls.forEach(pnl => {
    runningCapital += pnl;
    if (runningCapital > peak) {
      peak = runningCapital;
    }
    const drawdown = ((peak - runningCapital) / peak) * 100;
    maxDrawdown = Math.max(maxDrawdown, drawdown);
  });
  
  // Sharpe Ratio (simplified - assuming risk-free rate = 0)
  const avgReturn = totalPnL / completedTrades.length;
  const variance = pnls.reduce((sum, p) => sum + Math.pow(p - avgReturn, 2), 0) / completedTrades.length;
  const stdDev = Math.sqrt(variance);
  const sharpeRatio = stdDev > 0 ? (avgReturn / stdDev) * Math.sqrt(252) : 0;
  
  const roi = initialCapital > 0 ? (totalPnL / initialCapital) * 100 : 0;
  
  return {
    totalTrades: completedTrades.length,
    winRate,
    totalPnL,
    bestTrade: Math.max(...pnls, 0),
    worstTrade: Math.min(...pnls, 0),
    avgWin,
    avgLoss,
    profitFactor,
    expectancy,
    maxConsecutiveWins,
    maxConsecutiveLosses,
    maxDrawdown,
    sharpeRatio,
    currentStreak,
    roi,
  };
}

export function getPatternInsights(trades: Trade[]) {
  const completedTrades = trades.filter(t => t.exitPrice);
  
  // Day of week analysis
  const dayPerformance: Record<string, { pnl: number; count: number }> = {};
  const hourPerformance: Record<number, { pnl: number; count: number }> = {};
  const emotionPerformance: Record<string, { pnl: number; count: number }> = {};
  const strategyPerformance: Record<string, { pnl: number; count: number }> = {};
  const symbolPerformance: Record<string, { pnl: number; count: number }> = {};
  
  completedTrades.forEach(trade => {
    const pnl = calculatePnL(trade);
    const date = new Date(trade.entryDate);
    const dayName = date.toLocaleDateString('en-US', { weekday: 'long' });
    const hour = parseInt(trade.entryTime?.split(':')[0] || '0');
    
    // Day performance
    if (!dayPerformance[dayName]) dayPerformance[dayName] = { pnl: 0, count: 0 };
    dayPerformance[dayName].pnl += pnl;
    dayPerformance[dayName].count++;
    
    // Hour performance
    if (!hourPerformance[hour]) hourPerformance[hour] = { pnl: 0, count: 0 };
    hourPerformance[hour].pnl += pnl;
    hourPerformance[hour].count++;
    
    // Emotion performance
    if (trade.emotionBefore) {
      if (!emotionPerformance[trade.emotionBefore]) {
        emotionPerformance[trade.emotionBefore] = { pnl: 0, count: 0 };
      }
      emotionPerformance[trade.emotionBefore].pnl += pnl;
      emotionPerformance[trade.emotionBefore].count++;
    }
    
    // Strategy performance
    if (trade.strategyTag) {
      if (!strategyPerformance[trade.strategyTag]) {
        strategyPerformance[trade.strategyTag] = { pnl: 0, count: 0 };
      }
      strategyPerformance[trade.strategyTag].pnl += pnl;
      strategyPerformance[trade.strategyTag].count++;
    }
    
    // Symbol performance
    if (!symbolPerformance[trade.symbol]) {
      symbolPerformance[trade.symbol] = { pnl: 0, count: 0 };
    }
    symbolPerformance[trade.symbol].pnl += pnl;
    symbolPerformance[trade.symbol].count++;
  });
  
  return {
    dayPerformance,
    hourPerformance,
    emotionPerformance,
    strategyPerformance,
    symbolPerformance,
  };
}

export function generateInsights(trades: Trade[], analytics: Analytics) {
  const insights: string[] = [];
  const patterns = getPatternInsights(trades);
  
  // Best day
  const bestDay = Object.entries(patterns.dayPerformance)
    .sort((a, b) => b[1].pnl - a[1].pnl)[0];
  if (bestDay) {
    insights.push(`📅 Aapka best trading day hai ${bestDay[0]} with average P&L of ₹${(bestDay[1].pnl / bestDay[1].count).toFixed(2)}`);
  }
  
  // Best time
  const bestHour = Object.entries(patterns.hourPerformance)
    .sort((a, b) => b[1].pnl - a[1].pnl)[0];
  if (bestHour) {
    insights.push(`⏰ Aap ${bestHour[0]}:00 ke baad better perform karte ho`);
  }
  
  // Emotion correlation
  const emotionData = Object.entries(patterns.emotionPerformance);
  if (emotionData.length > 0) {
    const bestEmotion = emotionData.sort((a, b) => b[1].pnl - a[1].pnl)[0];
    insights.push(`😊 ${bestEmotion[0]} emotion se best results aate hain`);
  }
  
  // Best strategy
  const strategyData = Object.entries(patterns.strategyPerformance);
  if (strategyData.length > 0) {
    const bestStrategy = strategyData.sort((a, b) => b[1].pnl - a[1].pnl)[0];
    insights.push(`🎯 ${bestStrategy[0]} strategy sabse profitable hai`);
  }
  
  // Warning signs
  if (analytics.currentStreak < -3) {
    insights.push(`⚠️ RED FLAG: Aap ${Math.abs(analytics.currentStreak)} consecutive losses mein ho. Break lo aur plan review karo!`);
  }
  
  if (analytics.winRate < 40) {
    insights.push(`⚠️ Win rate ${analytics.winRate.toFixed(1)}% hai. Strategy review ki zarurat hai.`);
  }
  
  if (analytics.avgLoss > analytics.avgWin) {
    insights.push(`⚠️ Average loss (₹${analytics.avgLoss.toFixed(2)}) average win (₹${analytics.avgWin.toFixed(2)}) se zyada hai. Risk management improve karo!`);
  }
  
  // Positive insights
  if (analytics.winRate > 60) {
    insights.push(`✅ Excellent win rate of ${analytics.winRate.toFixed(1)}%! Keep it up!`);
  }
  
  if (analytics.profitFactor > 2) {
    insights.push(`✅ Strong profit factor of ${analytics.profitFactor.toFixed(2)}! Your edge is working!`);
  }
  
  return insights;
}
