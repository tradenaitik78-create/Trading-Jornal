import { Trade, Folder, Goal } from '../types/trading';

const STORAGE_KEYS = {
  FOLDERS: 'trading_journal_folders',
  TRADES: 'trading_journal_trades',
  GOALS: 'trading_journal_goals',
  THEME: 'trading_journal_theme',
};

export const storage = {
  // Folders
  getFolders: (): Folder[] => {
    const data = localStorage.getItem(STORAGE_KEYS.FOLDERS);
    return data ? JSON.parse(data) : [];
  },
  
  saveFolders: (folders: Folder[]) => {
    localStorage.setItem(STORAGE_KEYS.FOLDERS, JSON.stringify(folders));
  },
  
  // Trades
  getTrades: (): Trade[] => {
    const data = localStorage.getItem(STORAGE_KEYS.TRADES);
    return data ? JSON.parse(data) : [];
  },
  
  saveTrades: (trades: Trade[]) => {
    localStorage.setItem(STORAGE_KEYS.TRADES, JSON.stringify(trades));
  },
  
  // Goals
  getGoals: (): Goal[] => {
    const data = localStorage.getItem(STORAGE_KEYS.GOALS);
    return data ? JSON.parse(data) : [];
  },
  
  saveGoals: (goals: Goal[]) => {
    localStorage.setItem(STORAGE_KEYS.GOALS, JSON.stringify(goals));
  },
  
  // Export data
  exportData: (folderId?: string) => {
    const folders = storage.getFolders();
    const trades = storage.getTrades();
    const goals = storage.getGoals();
    
    if (folderId) {
      return {
        folders: folders.filter(f => f.id === folderId),
        trades: trades.filter(t => t.folderId === folderId),
        goals: goals.filter(g => g.folderId === folderId),
      };
    }
    
    return { folders, trades, goals };
  },
  
  // Import data
  importData: (data: { folders?: Folder[]; trades?: Trade[]; goals?: Goal[] }) => {
    if (data.folders) {
      const existingFolders = storage.getFolders();
      storage.saveFolders([...existingFolders, ...data.folders]);
    }
    if (data.trades) {
      const existingTrades = storage.getTrades();
      storage.saveTrades([...existingTrades, ...data.trades]);
    }
    if (data.goals) {
      const existingGoals = storage.getGoals();
      storage.saveGoals([...existingGoals, ...data.goals]);
    }
  },
  
  // Clear all data
  clearAll: () => {
    localStorage.removeItem(STORAGE_KEYS.FOLDERS);
    localStorage.removeItem(STORAGE_KEYS.TRADES);
    localStorage.removeItem(STORAGE_KEYS.GOALS);
  },
};
