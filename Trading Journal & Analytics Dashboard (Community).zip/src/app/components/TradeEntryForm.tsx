import { useState } from 'react';
import { Trade } from '../types/trading';
import { X, ChevronDown, ChevronUp } from 'lucide-react';
import { calculatePnL, calculateRiskReward } from '../utils/calculations';

interface TradeEntryFormProps {
  trade?: Trade;
  folderId: string;
  onSave: (trade: Omit<Trade, 'id' | 'createdAt' | 'updatedAt'>) => void;
  onClose: () => void;
}

export function TradeEntryForm({ trade, folderId, onSave, onClose }: TradeEntryFormProps) {
  const [showAdvanced, setShowAdvanced] = useState(false);
  const [showJournal, setShowJournal] = useState(false);
  
  const [formData, setFormData] = useState<Partial<Trade>>({
    folderId,
    tradeType: trade?.tradeType || 'long',
    entryDate: trade?.entryDate || new Date().toISOString().split('T')[0],
    entryTime: trade?.entryTime || new Date().toTimeString().slice(0, 5),
    exitDate: trade?.exitDate,
    exitTime: trade?.exitTime,
    symbol: trade?.symbol || '',
    entryPrice: trade?.entryPrice || 0,
    exitPrice: trade?.exitPrice,
    quantity: trade?.quantity || 0,
    stopLoss: trade?.stopLoss,
    target: trade?.target,
    marketCondition: trade?.marketCondition,
    timeframe: trade?.timeframe,
    strategyTag: trade?.strategyTag,
    emotionBefore: trade?.emotionBefore,
    setupQuality: trade?.setupQuality,
    positionSizePercent: trade?.positionSizePercent,
    preTradePlan: trade?.preTradePlan,
    tradeReasoning: trade?.tradeReasoning,
    postTradeReview: trade?.postTradeReview,
    lessonsLearned: trade?.lessonsLearned,
    mistakes: trade?.mistakes,
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const tradeData = formData as Omit<Trade, 'id' | 'createdAt' | 'updatedAt'>;
    tradeData.pnl = calculatePnL(tradeData as Trade);
    tradeData.riskRewardRatio = calculateRiskReward(tradeData as Trade);
    
    onSave(tradeData);
  };

  const updateField = (field: keyof Trade, value: any) => {
    setFormData({ ...formData, [field]: value });
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="bg-gray-900 rounded-lg w-full max-w-3xl max-h-[90vh] overflow-y-auto">
        <div className="sticky top-0 bg-gray-900 border-b border-gray-800 p-4 flex items-center justify-between">
          <h2 className="font-semibold text-white">
            {trade ? 'Edit Trade' : 'Add New Trade'}
          </h2>
          <button onClick={onClose} className="text-gray-400 hover:text-white">
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-4 space-y-4">
          {/* Basic Information */}
          <div className="space-y-4">
            <h3 className="font-medium text-white">Basic Information</h3>
            
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm text-gray-400 mb-1">Trade Type</label>
                <select
                  value={formData.tradeType}
                  onChange={(e) => updateField('tradeType', e.target.value)}
                  className="w-full px-3 py-2 bg-gray-800 text-white rounded border border-gray-700"
                  required
                >
                  <option value="long">Long</option>
                  <option value="short">Short</option>
                </select>
              </div>
              
              <div>
                <label className="block text-sm text-gray-400 mb-1">Symbol/Stock</label>
                <input
                  type="text"
                  value={formData.symbol}
                  onChange={(e) => updateField('symbol', e.target.value)}
                  className="w-full px-3 py-2 bg-gray-800 text-white rounded border border-gray-700"
                  placeholder="e.g., RELIANCE, NIFTY"
                  required
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm text-gray-400 mb-1">Entry Date</label>
                <input
                  type="date"
                  value={formData.entryDate}
                  onChange={(e) => updateField('entryDate', e.target.value)}
                  className="w-full px-3 py-2 bg-gray-800 text-white rounded border border-gray-700"
                  required
                />
              </div>
              
              <div>
                <label className="block text-sm text-gray-400 mb-1">Entry Time</label>
                <input
                  type="time"
                  value={formData.entryTime}
                  onChange={(e) => updateField('entryTime', e.target.value)}
                  className="w-full px-3 py-2 bg-gray-800 text-white rounded border border-gray-700"
                  required
                />
              </div>
            </div>

            <div className="grid grid-cols-3 gap-4">
              <div>
                <label className="block text-sm text-gray-400 mb-1">Entry Price</label>
                <input
                  type="number"
                  step="0.01"
                  value={formData.entryPrice}
                  onChange={(e) => updateField('entryPrice', Number(e.target.value))}
                  className="w-full px-3 py-2 bg-gray-800 text-white rounded border border-gray-700"
                  required
                />
              </div>
              
              <div>
                <label className="block text-sm text-gray-400 mb-1">Quantity</label>
                <input
                  type="number"
                  value={formData.quantity}
                  onChange={(e) => updateField('quantity', Number(e.target.value))}
                  className="w-full px-3 py-2 bg-gray-800 text-white rounded border border-gray-700"
                  required
                />
              </div>
              
              <div>
                <label className="block text-sm text-gray-400 mb-1">Exit Price</label>
                <input
                  type="number"
                  step="0.01"
                  value={formData.exitPrice || ''}
                  onChange={(e) => updateField('exitPrice', e.target.value ? Number(e.target.value) : undefined)}
                  className="w-full px-3 py-2 bg-gray-800 text-white rounded border border-gray-700"
                  placeholder="Optional"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm text-gray-400 mb-1">Stop Loss</label>
                <input
                  type="number"
                  step="0.01"
                  value={formData.stopLoss || ''}
                  onChange={(e) => updateField('stopLoss', e.target.value ? Number(e.target.value) : undefined)}
                  className="w-full px-3 py-2 bg-gray-800 text-white rounded border border-gray-700"
                  placeholder="Optional"
                />
              </div>
              
              <div>
                <label className="block text-sm text-gray-400 mb-1">Target</label>
                <input
                  type="number"
                  step="0.01"
                  value={formData.target || ''}
                  onChange={(e) => updateField('target', e.target.value ? Number(e.target.value) : undefined)}
                  className="w-full px-3 py-2 bg-gray-800 text-white rounded border border-gray-700"
                  placeholder="Optional"
                />
              </div>
            </div>
          </div>

          {/* Advanced Fields */}
          <div className="border-t border-gray-800 pt-4">
            <button
              type="button"
              onClick={() => setShowAdvanced(!showAdvanced)}
              className="flex items-center gap-2 text-blue-400 hover:text-blue-300 text-sm"
            >
              {showAdvanced ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
              Advanced Details
            </button>

            {showAdvanced && (
              <div className="mt-4 space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm text-gray-400 mb-1">Market Condition</label>
                    <select
                      value={formData.marketCondition || ''}
                      onChange={(e) => updateField('marketCondition', e.target.value || undefined)}
                      className="w-full px-3 py-2 bg-gray-800 text-white rounded border border-gray-700"
                    >
                      <option value="">Select...</option>
                      <option value="trending">Trending</option>
                      <option value="ranging">Ranging</option>
                      <option value="volatile">Volatile</option>
                    </select>
                  </div>
                  
                  <div>
                    <label className="block text-sm text-gray-400 mb-1">Timeframe</label>
                    <input
                      type="text"
                      value={formData.timeframe || ''}
                      onChange={(e) => updateField('timeframe', e.target.value)}
                      className="w-full px-3 py-2 bg-gray-800 text-white rounded border border-gray-700"
                      placeholder="e.g., 15m, 1H, 1D"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm text-gray-400 mb-1">Strategy Tag</label>
                    <input
                      type="text"
                      value={formData.strategyTag || ''}
                      onChange={(e) => updateField('strategyTag', e.target.value)}
                      className="w-full px-3 py-2 bg-gray-800 text-white rounded border border-gray-700"
                      placeholder="e.g., Breakout, Reversal"
                    />
                  </div>
                  
                  <div>
                    <label className="block text-sm text-gray-400 mb-1">Emotion Before Trade</label>
                    <select
                      value={formData.emotionBefore || ''}
                      onChange={(e) => updateField('emotionBefore', e.target.value || undefined)}
                      className="w-full px-3 py-2 bg-gray-800 text-white rounded border border-gray-700"
                    >
                      <option value="">Select...</option>
                      <option value="fear">Fear</option>
                      <option value="greed">Greed</option>
                      <option value="confident">Confident</option>
                      <option value="neutral">Neutral</option>
                    </select>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm text-gray-400 mb-1">Setup Quality (1-10)</label>
                    <input
                      type="number"
                      min="1"
                      max="10"
                      value={formData.setupQuality || ''}
                      onChange={(e) => updateField('setupQuality', e.target.value ? Number(e.target.value) : undefined)}
                      className="w-full px-3 py-2 bg-gray-800 text-white rounded border border-gray-700"
                    />
                  </div>
                  
                  <div>
                    <label className="block text-sm text-gray-400 mb-1">Position Size (% of Capital)</label>
                    <input
                      type="number"
                      step="0.1"
                      value={formData.positionSizePercent || ''}
                      onChange={(e) => updateField('positionSizePercent', e.target.value ? Number(e.target.value) : undefined)}
                      className="w-full px-3 py-2 bg-gray-800 text-white rounded border border-gray-700"
                    />
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Journal Section */}
          <div className="border-t border-gray-800 pt-4">
            <button
              type="button"
              onClick={() => setShowJournal(!showJournal)}
              className="flex items-center gap-2 text-blue-400 hover:text-blue-300 text-sm"
            >
              {showJournal ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
              Journal & Notes
            </button>

            {showJournal && (
              <div className="mt-4 space-y-4">
                <div>
                  <label className="block text-sm text-gray-400 mb-1">Pre-Trade Plan</label>
                  <textarea
                    value={formData.preTradePlan || ''}
                    onChange={(e) => updateField('preTradePlan', e.target.value)}
                    className="w-full px-3 py-2 bg-gray-800 text-white rounded border border-gray-700 h-20"
                    placeholder="What's your plan for this trade?"
                  />
                </div>

                <div>
                  <label className="block text-sm text-gray-400 mb-1">Trade Reasoning</label>
                  <textarea
                    value={formData.tradeReasoning || ''}
                    onChange={(e) => updateField('tradeReasoning', e.target.value)}
                    className="w-full px-3 py-2 bg-gray-800 text-white rounded border border-gray-700 h-20"
                    placeholder="Why did you take this trade?"
                  />
                </div>

                <div>
                  <label className="block text-sm text-gray-400 mb-1">Post-Trade Review</label>
                  <textarea
                    value={formData.postTradeReview || ''}
                    onChange={(e) => updateField('postTradeReview', e.target.value)}
                    className="w-full px-3 py-2 bg-gray-800 text-white rounded border border-gray-700 h-20"
                    placeholder="How did the trade go?"
                  />
                </div>

                <div>
                  <label className="block text-sm text-gray-400 mb-1">Lessons Learned</label>
                  <textarea
                    value={formData.lessonsLearned || ''}
                    onChange={(e) => updateField('lessonsLearned', e.target.value)}
                    className="w-full px-3 py-2 bg-gray-800 text-white rounded border border-gray-700 h-20"
                    placeholder="What did you learn?"
                  />
                </div>

                <div>
                  <label className="block text-sm text-gray-400 mb-1">Mistakes</label>
                  <textarea
                    value={formData.mistakes || ''}
                    onChange={(e) => updateField('mistakes', e.target.value)}
                    className="w-full px-3 py-2 bg-gray-800 text-white rounded border border-gray-700 h-20"
                    placeholder="What mistakes did you make?"
                  />
                </div>
              </div>
            )}
          </div>

          {/* Actions */}
          <div className="flex gap-3 pt-4">
            <button
              type="submit"
              className="flex-1 px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700"
            >
              {trade ? 'Update Trade' : 'Add Trade'}
            </button>
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 bg-gray-700 text-white rounded hover:bg-gray-600"
            >
              Cancel
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
