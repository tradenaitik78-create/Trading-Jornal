import { Trade } from '../types/trading';
import { Edit2, Trash2, TrendingUp, TrendingDown } from 'lucide-react';
import { calculatePnL } from '../utils/calculations';

interface TradesTableProps {
  trades: Trade[];
  onEdit: (trade: Trade) => void;
  onDelete: (id: string) => void;
}

export function TradesTable({ trades, onEdit, onDelete }: TradesTableProps) {
  const sortedTrades = [...trades].sort((a, b) => 
    new Date(b.entryDate).getTime() - new Date(a.entryDate).getTime()
  );

  if (trades.length === 0) {
    return (
      <div className="bg-gray-800 rounded-lg p-8 text-center">
        <div className="text-gray-400">
          No trades recorded yet. Click "Add Trade" to get started!
        </div>
      </div>
    );
  }

  return (
    <div className="bg-gray-800 rounded-lg overflow-hidden">
      <div className="overflow-x-auto">
        <table className="w-full">
          <thead className="bg-gray-900 border-b border-gray-700">
            <tr className="text-left text-gray-400 text-sm">
              <th className="px-4 py-3">Date</th>
              <th className="px-4 py-3">Symbol</th>
              <th className="px-4 py-3">Type</th>
              <th className="px-4 py-3">Entry</th>
              <th className="px-4 py-3">Exit</th>
              <th className="px-4 py-3">Qty</th>
              <th className="px-4 py-3">P&L</th>
              <th className="px-4 py-3">Strategy</th>
              <th className="px-4 py-3">Actions</th>
            </tr>
          </thead>
          <tbody>
            {sortedTrades.map((trade) => {
              const pnl = calculatePnL(trade);
              return (
                <tr
                  key={trade.id}
                  className="border-b border-gray-700/50 hover:bg-gray-700/30 transition-colors"
                >
                  <td className="px-4 py-3 text-sm text-gray-300">
                    {new Date(trade.entryDate).toLocaleDateString()}
                    <div className="text-xs text-gray-500">{trade.entryTime}</div>
                  </td>
                  <td className="px-4 py-3 text-white font-medium">
                    {trade.symbol}
                  </td>
                  <td className="px-4 py-3">
                    <span className={`inline-flex items-center gap-1 px-2 py-1 rounded text-xs ${
                      trade.tradeType === 'long' 
                        ? 'bg-green-500/20 text-green-400' 
                        : 'bg-red-500/20 text-red-400'
                    }`}>
                      {trade.tradeType === 'long' ? (
                        <TrendingUp className="w-3 h-3" />
                      ) : (
                        <TrendingDown className="w-3 h-3" />
                      )}
                      {trade.tradeType.toUpperCase()}
                    </span>
                  </td>
                  <td className="px-4 py-3 text-sm text-gray-300">
                    ₹{trade.entryPrice.toFixed(2)}
                  </td>
                  <td className="px-4 py-3 text-sm text-gray-300">
                    {trade.exitPrice ? `₹${trade.exitPrice.toFixed(2)}` : '-'}
                  </td>
                  <td className="px-4 py-3 text-sm text-gray-300">
                    {trade.quantity}
                  </td>
                  <td className="px-4 py-3">
                    {trade.exitPrice ? (
                      <span className={`font-semibold ${pnl >= 0 ? 'text-green-500' : 'text-red-500'}`}>
                        {pnl >= 0 ? '+' : ''}₹{pnl.toFixed(2)}
                      </span>
                    ) : (
                      <span className="text-gray-500 text-sm">Open</span>
                    )}
                  </td>
                  <td className="px-4 py-3 text-sm text-gray-400">
                    {trade.strategyTag || '-'}
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex gap-2">
                      <button
                        onClick={() => onEdit(trade)}
                        className="p-1 hover:bg-gray-600 rounded text-blue-400"
                      >
                        <Edit2 className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => {
                          if (confirm('Delete this trade?')) {
                            onDelete(trade.id);
                          }
                        }}
                        className="p-1 hover:bg-gray-600 rounded text-red-400"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}
