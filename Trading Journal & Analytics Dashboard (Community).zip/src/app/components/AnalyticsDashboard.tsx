import { Trade, Folder as FolderType, Analytics } from '../types/trading';
import { TrendingUp, TrendingDown, Target, Award, AlertTriangle, Activity } from 'lucide-react';
import { LineChart, Line, BarChart, Bar, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Area, AreaChart } from 'recharts';
import { calculatePnL, getPatternInsights, generateInsights } from '../utils/calculations';

interface AnalyticsDashboardProps {
  trades: Trade[];
  folder: FolderType;
  analytics: Analytics;
}

export function AnalyticsDashboard({ trades, folder, analytics }: AnalyticsDashboardProps) {
  const completedTrades = trades.filter(t => t.exitPrice);
  const insights = generateInsights(trades, analytics);
  const patterns = getPatternInsights(trades);

  // Equity curve data
  const equityCurveData = completedTrades.map((trade, index) => {
    const pnl = calculatePnL(trade);
    const cumulative = completedTrades
      .slice(0, index + 1)
      .reduce((sum, t) => sum + calculatePnL(t), 0);
    
    return {
      index: index + 1,
      pnl: cumulative + folder.initialCapital,
      date: new Date(trade.entryDate).toLocaleDateString(),
    };
  });

  // Win/Loss pie data
  const winCount = completedTrades.filter(t => calculatePnL(t) > 0).length;
  const lossCount = completedTrades.length - winCount;
  const pieData = [
    { name: 'Wins', value: winCount, color: '#10B981' },
    { name: 'Losses', value: lossCount, color: '#EF4444' },
  ];

  // Day performance data
  const dayData = Object.entries(patterns.dayPerformance).map(([day, data]) => ({
    day: day.slice(0, 3),
    pnl: data.pnl,
    trades: data.count,
  }));

  // Hour performance data
  const hourData = Object.entries(patterns.hourPerformance)
    .sort((a, b) => Number(a[0]) - Number(b[0]))
    .map(([hour, data]) => ({
      hour: `${hour}:00`,
      pnl: data.pnl,
    }));

  // Strategy performance
  const strategyData = Object.entries(patterns.strategyPerformance).map(([strategy, data]) => ({
    strategy,
    pnl: data.pnl,
    trades: data.count,
    avg: data.pnl / data.count,
  }));

  // Symbol performance
  const symbolData = Object.entries(patterns.symbolPerformance)
    .sort((a, b) => b[1].pnl - a[1].pnl)
    .slice(0, 10)
    .map(([symbol, data]) => ({
      symbol,
      pnl: data.pnl,
    }));

  return (
    <div className="space-y-6">
      {/* Key Metrics */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <MetricCard
          title="Total P&L"
          value={`₹${analytics.totalPnL.toFixed(2)}`}
          icon={analytics.totalPnL >= 0 ? TrendingUp : TrendingDown}
          color={analytics.totalPnL >= 0 ? 'green' : 'red'}
        />
        <MetricCard
          title="Win Rate"
          value={`${analytics.winRate.toFixed(1)}%`}
          icon={Target}
          color={analytics.winRate >= 50 ? 'green' : 'red'}
        />
        <MetricCard
          title="Total Trades"
          value={analytics.totalTrades.toString()}
          icon={Activity}
          color="blue"
        />
        <MetricCard
          title="ROI"
          value={`${analytics.roi.toFixed(2)}%`}
          icon={Award}
          color={analytics.roi >= 0 ? 'green' : 'red'}
        />
      </div>

      {/* Secondary Metrics */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
        <div className="bg-gray-800 p-4 rounded-lg">
          <div className="text-sm text-gray-400">Best Trade</div>
          <div className="text-green-500">₹{analytics.bestTrade.toFixed(2)}</div>
        </div>
        <div className="bg-gray-800 p-4 rounded-lg">
          <div className="text-sm text-gray-400">Worst Trade</div>
          <div className="text-red-500">₹{analytics.worstTrade.toFixed(2)}</div>
        </div>
        <div className="bg-gray-800 p-4 rounded-lg">
          <div className="text-sm text-gray-400">Profit Factor</div>
          <div className={analytics.profitFactor >= 1.5 ? 'text-green-500' : 'text-yellow-500'}>
            {analytics.profitFactor.toFixed(2)}
          </div>
        </div>
        <div className="bg-gray-800 p-4 rounded-lg">
          <div className="text-sm text-gray-400">Max Drawdown</div>
          <div className="text-red-500">{analytics.maxDrawdown.toFixed(2)}%</div>
        </div>
        <div className="bg-gray-800 p-4 rounded-lg">
          <div className="text-sm text-gray-400">Sharpe Ratio</div>
          <div className={analytics.sharpeRatio >= 1 ? 'text-green-500' : 'text-yellow-500'}>
            {analytics.sharpeRatio.toFixed(2)}
          </div>
        </div>
      </div>

      {/* AI Insights */}
      {insights.length > 0 && (
        <div className="bg-gradient-to-r from-purple-900/30 to-blue-900/30 p-4 rounded-lg border border-purple-500/20">
          <h3 className="font-semibold text-white mb-3 flex items-center gap-2">
            🧪 AI-Powered Insights
          </h3>
          <div className="space-y-2">
            {insights.map((insight, i) => (
              <div key={i} className="text-sm text-gray-300 flex items-start gap-2">
                <span className="text-purple-400">•</span>
                <span>{insight}</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Equity Curve */}
      {equityCurveData.length > 0 && (
        <div className="bg-gray-800 p-4 rounded-lg">
          <h3 className="font-semibold text-white mb-4">Equity Curve</h3>
          <ResponsiveContainer width="100%" height={250}>
            <AreaChart data={equityCurveData}>
              <defs>
                <linearGradient id="colorPnl" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#3B82F6" stopOpacity={0.3}/>
                  <stop offset="95%" stopColor="#3B82F6" stopOpacity={0}/>
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
              <XAxis dataKey="index" stroke="#9CA3AF" />
              <YAxis stroke="#9CA3AF" />
              <Tooltip
                contentStyle={{ backgroundColor: '#1F2937', border: '1px solid #374151' }}
                labelStyle={{ color: '#F3F4F6' }}
              />
              <Area type="monotone" dataKey="pnl" stroke="#3B82F6" fillOpacity={1} fill="url(#colorPnl)" />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Win/Loss Distribution */}
        {pieData[0].value > 0 || pieData[1].value > 0 ? (
          <div className="bg-gray-800 p-4 rounded-lg">
            <h3 className="font-semibold text-white mb-4">Win/Loss Distribution</h3>
            <ResponsiveContainer width="100%" height={250}>
              <PieChart>
                <Pie
                  data={pieData}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {pieData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip
                  contentStyle={{ backgroundColor: '#1F2937', border: '1px solid #374151' }}
                />
              </PieChart>
            </ResponsiveContainer>
          </div>
        ) : null}

        {/* Day Performance */}
        {dayData.length > 0 && (
          <div className="bg-gray-800 p-4 rounded-lg">
            <h3 className="font-semibold text-white mb-4">Performance by Day</h3>
            <ResponsiveContainer width="100%" height={250}>
              <BarChart data={dayData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                <XAxis dataKey="day" stroke="#9CA3AF" />
                <YAxis stroke="#9CA3AF" />
                <Tooltip
                  contentStyle={{ backgroundColor: '#1F2937', border: '1px solid #374151' }}
                  labelStyle={{ color: '#F3F4F6' }}
                />
                <Bar dataKey="pnl" fill="#3B82F6" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        )}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Hour Performance */}
        {hourData.length > 0 && (
          <div className="bg-gray-800 p-4 rounded-lg">
            <h3 className="font-semibold text-white mb-4">Performance by Hour</h3>
            <ResponsiveContainer width="100%" height={250}>
              <LineChart data={hourData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                <XAxis dataKey="hour" stroke="#9CA3AF" />
                <YAxis stroke="#9CA3AF" />
                <Tooltip
                  contentStyle={{ backgroundColor: '#1F2937', border: '1px solid #374151' }}
                  labelStyle={{ color: '#F3F4F6' }}
                />
                <Line type="monotone" dataKey="pnl" stroke="#10B981" strokeWidth={2} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        )}

        {/* Symbol Performance */}
        {symbolData.length > 0 && (
          <div className="bg-gray-800 p-4 rounded-lg">
            <h3 className="font-semibold text-white mb-4">Top Symbols by P&L</h3>
            <ResponsiveContainer width="100%" height={250}>
              <BarChart data={symbolData} layout="vertical">
                <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                <XAxis type="number" stroke="#9CA3AF" />
                <YAxis type="category" dataKey="symbol" stroke="#9CA3AF" width={80} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#1F2937', border: '1px solid #374151' }}
                  labelStyle={{ color: '#F3F4F6' }}
                />
                <Bar dataKey="pnl" fill="#8B5CF6" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        )}
      </div>

      {/* Strategy Performance */}
      {strategyData.length > 0 && (
        <div className="bg-gray-800 p-4 rounded-lg">
          <h3 className="font-semibold text-white mb-4">Strategy Performance</h3>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="border-b border-gray-700">
                <tr className="text-gray-400">
                  <th className="text-left py-2">Strategy</th>
                  <th className="text-right py-2">Trades</th>
                  <th className="text-right py-2">Total P&L</th>
                  <th className="text-right py-2">Avg P&L</th>
                </tr>
              </thead>
              <tbody>
                {strategyData.map((strategy, i) => (
                  <tr key={i} className="border-b border-gray-700/50">
                    <td className="py-2 text-white">{strategy.strategy}</td>
                    <td className="text-right text-gray-300">{strategy.trades}</td>
                    <td className={`text-right ${strategy.pnl >= 0 ? 'text-green-500' : 'text-red-500'}`}>
                      ₹{strategy.pnl.toFixed(2)}
                    </td>
                    <td className={`text-right ${strategy.avg >= 0 ? 'text-green-500' : 'text-red-500'}`}>
                      ₹{strategy.avg.toFixed(2)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}

interface MetricCardProps {
  title: string;
  value: string;
  icon: React.ElementType;
  color: 'green' | 'red' | 'blue' | 'yellow';
}

function MetricCard({ title, value, icon: Icon, color }: MetricCardProps) {
  const colorClasses = {
    green: 'text-green-500 bg-green-500/10',
    red: 'text-red-500 bg-red-500/10',
    blue: 'text-blue-500 bg-blue-500/10',
    yellow: 'text-yellow-500 bg-yellow-500/10',
  };

  return (
    <div className="bg-gray-800 p-4 rounded-lg">
      <div className="flex items-center justify-between">
        <div>
          <div className="text-sm text-gray-400">{title}</div>
          <div className={`text-2xl font-semibold ${colorClasses[color].split(' ')[0]}`}>
            {value}
          </div>
        </div>
        <div className={`p-3 rounded-lg ${colorClasses[color]}`}>
          <Icon className="w-6 h-6" />
        </div>
      </div>
    </div>
  );
}
