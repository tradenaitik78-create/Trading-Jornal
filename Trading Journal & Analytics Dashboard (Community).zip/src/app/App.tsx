import { useState, useEffect } from 'react';
import { Trade, Folder, Goal } from './types/trading';
import { FolderSidebar } from './components/FolderSidebar';
import { TradeEntryForm } from './components/TradeEntryForm';
import { AnalyticsDashboard } from './components/AnalyticsDashboard';
import { TradesTable } from './components/TradesTable';
import { GoalTracker } from './components/GoalTracker';
import { storage } from './utils/storage';
import { calculateAnalytics } from './utils/calculations';
import { Plus, BarChart3, List, Moon, Sun, Download, Upload } from 'lucide-react';

export default function App() {
  const [folders, setFolders] = useState<Folder[]>([]);
  const [trades, setTrades] = useState<Trade[]>([]);
  const [goals, setGoals] = useState<Goal[]>([]);
  const [selectedFolderId, setSelectedFolderId] = useState<string | null>(null);
  const [showTradeForm, setShowTradeForm] = useState(false);
  const [editingTrade, setEditingTrade] = useState<Trade | undefined>();
  const [activeTab, setActiveTab] = useState<'analytics' | 'trades'>('analytics');
  const [darkMode, setDarkMode] = useState(true);

  // Load data from localStorage
  useEffect(() => {
    const loadedFolders = storage.getFolders();
    const loadedTrades = storage.getTrades();
    const loadedGoals = storage.getGoals();
    
    setFolders(loadedFolders);
    setTrades(loadedTrades);
    setGoals(loadedGoals);
    
    if (loadedFolders.length > 0 && !selectedFolderId) {
      setSelectedFolderId(loadedFolders[0].id);
    }
  }, []);

  // Create default folder if none exist
  useEffect(() => {
    if (folders.length === 0) {
      const defaultFolder: Folder = {
        id: crypto.randomUUID(),
        name: 'Main Portfolio',
        color: '#3B82F6',
        description: 'Default trading portfolio',
        createdAt: new Date().toISOString(),
        initialCapital: 100000,
      };
      setFolders([defaultFolder]);
      setSelectedFolderId(defaultFolder.id);
      storage.saveFolders([defaultFolder]);
    }
  }, [folders]);

  const selectedFolder = folders.find(f => f.id === selectedFolderId);
  const folderTrades = trades.filter(t => t.folderId === selectedFolderId);
  const folderGoals = goals.filter(g => g.folderId === selectedFolderId);
  const analytics = selectedFolder ? calculateAnalytics(folderTrades, selectedFolder.initialCapital) : null;

  // Folder operations
  const handleAddFolder = (folderData: Omit<Folder, 'id' | 'createdAt'>) => {
    const newFolder: Folder = {
      ...folderData,
      id: crypto.randomUUID(),
      createdAt: new Date().toISOString(),
    };
    const updatedFolders = [...folders, newFolder];
    setFolders(updatedFolders);
    storage.saveFolders(updatedFolders);
    setSelectedFolderId(newFolder.id);
  };

  const handleEditFolder = (id: string, updates: Partial<Folder>) => {
    const updatedFolders = folders.map(f => f.id === id ? { ...f, ...updates } : f);
    setFolders(updatedFolders);
    storage.saveFolders(updatedFolders);
  };

  const handleDeleteFolder = (id: string) => {
    const updatedFolders = folders.filter(f => f.id !== id);
    const updatedTrades = trades.filter(t => t.folderId !== id);
    const updatedGoals = goals.filter(g => g.folderId !== id);
    
    setFolders(updatedFolders);
    setTrades(updatedTrades);
    setGoals(updatedGoals);
    
    storage.saveFolders(updatedFolders);
    storage.saveTrades(updatedTrades);
    storage.saveGoals(updatedGoals);
    
    if (selectedFolderId === id) {
      setSelectedFolderId(updatedFolders[0]?.id || null);
    }
  };

  // Trade operations
  const handleSaveTrade = (tradeData: Omit<Trade, 'id' | 'createdAt' | 'updatedAt'>) => {
    if (editingTrade) {
      const updatedTrades = trades.map(t =>
        t.id === editingTrade.id
          ? { ...tradeData, id: t.id, createdAt: t.createdAt, updatedAt: new Date().toISOString() } as Trade
          : t
      );
      setTrades(updatedTrades);
      storage.saveTrades(updatedTrades);
    } else {
      const newTrade: Trade = {
        ...tradeData,
        id: crypto.randomUUID(),
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };
      const updatedTrades = [...trades, newTrade];
      setTrades(updatedTrades);
      storage.saveTrades(updatedTrades);
    }
    
    setShowTradeForm(false);
    setEditingTrade(undefined);
  };

  const handleEditTrade = (trade: Trade) => {
    setEditingTrade(trade);
    setShowTradeForm(true);
  };

  const handleDeleteTrade = (id: string) => {
    const updatedTrades = trades.filter(t => t.id !== id);
    setTrades(updatedTrades);
    storage.saveTrades(updatedTrades);
  };

  // Goal operations
  const handleAddGoal = (goalData: Omit<Goal, 'id' | 'createdAt'>) => {
    const newGoal: Goal = {
      ...goalData,
      id: crypto.randomUUID(),
      createdAt: new Date().toISOString(),
    };
    const updatedGoals = [...goals, newGoal];
    setGoals(updatedGoals);
    storage.saveGoals(updatedGoals);
  };

  const handleDeleteGoal = (id: string) => {
    const updatedGoals = goals.filter(g => g.id !== id);
    setGoals(updatedGoals);
    storage.saveGoals(updatedGoals);
  };

  // Export/Import operations
  const handleExport = (folderId?: string) => {
    const data = storage.exportData(folderId);
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `trading-journal-${folderId || 'all'}-${new Date().toISOString().split('T')[0]}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleImport = () => {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = 'application/json';
    input.onchange = (e) => {
      const file = (e.target as HTMLInputElement).files?.[0];
      if (file) {
        const reader = new FileReader();
        reader.onload = (e) => {
          try {
            const data = JSON.parse(e.target?.result as string);
            storage.importData(data);
            
            // Reload data
            setFolders(storage.getFolders());
            setTrades(storage.getTrades());
            setGoals(storage.getGoals());
            
            alert('Data imported successfully!');
          } catch (error) {
            alert('Error importing data. Please check the file format.');
          }
        };
        reader.readAsText(file);
      }
    };
    input.click();
  };

  if (!selectedFolder) {
    return (
      <div className="min-h-screen bg-gray-950 flex items-center justify-center">
        <div className="text-white">Loading...</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-950 text-white flex">
      {/* Sidebar */}
      <FolderSidebar
        folders={folders}
        selectedFolderId={selectedFolderId}
        onSelectFolder={setSelectedFolderId}
        onAddFolder={handleAddFolder}
        onEditFolder={handleEditFolder}
        onDeleteFolder={handleDeleteFolder}
        onExport={handleExport}
        onImport={handleImport}
      />

      {/* Main Content */}
      <div className="flex-1 flex flex-col">
        {/* Header */}
        <header className="bg-gray-900 border-b border-gray-800 px-6 py-4">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-semibold">{selectedFolder.name}</h1>
              <p className="text-sm text-gray-400">
                Initial Capital: ₹{selectedFolder.initialCapital.toLocaleString()}
              </p>
            </div>
            <div className="flex items-center gap-3">
              <button
                onClick={() => handleExport(selectedFolderId || undefined)}
                className="px-4 py-2 bg-gray-800 hover:bg-gray-700 rounded flex items-center gap-2"
              >
                <Download className="w-4 h-4" />
                Export
              </button>
              <button
                onClick={() => {
                  setEditingTrade(undefined);
                  setShowTradeForm(true);
                }}
                className="px-4 py-2 bg-blue-600 hover:bg-blue-700 rounded flex items-center gap-2"
              >
                <Plus className="w-5 h-5" />
                Add Trade
              </button>
            </div>
          </div>
        </header>

        {/* Tabs */}
        <div className="bg-gray-900 border-b border-gray-800 px-6">
          <div className="flex gap-6">
            <button
              onClick={() => setActiveTab('analytics')}
              className={`py-3 flex items-center gap-2 border-b-2 transition-colors ${
                activeTab === 'analytics'
                  ? 'border-blue-500 text-white'
                  : 'border-transparent text-gray-400 hover:text-white'
              }`}
            >
              <BarChart3 className="w-4 h-4" />
              Analytics
            </button>
            <button
              onClick={() => setActiveTab('trades')}
              className={`py-3 flex items-center gap-2 border-b-2 transition-colors ${
                activeTab === 'trades'
                  ? 'border-blue-500 text-white'
                  : 'border-transparent text-gray-400 hover:text-white'
              }`}
            >
              <List className="w-4 h-4" />
              All Trades ({folderTrades.length})
            </button>
          </div>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto">
          <div className="p-6 max-w-7xl mx-auto">
            {activeTab === 'analytics' ? (
              <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
                <div className="lg:col-span-3">
                  {analytics && (
                    <AnalyticsDashboard
                      trades={folderTrades}
                      folder={selectedFolder}
                      analytics={analytics}
                    />
                  )}
                </div>
                <div className="lg:col-span-1">
                  <GoalTracker
                    goals={folderGoals}
                    folderId={selectedFolder.id}
                    currentPnL={analytics?.totalPnL || 0}
                    onAddGoal={handleAddGoal}
                    onDeleteGoal={handleDeleteGoal}
                  />
                </div>
              </div>
            ) : (
              <TradesTable
                trades={folderTrades}
                onEdit={handleEditTrade}
                onDelete={handleDeleteTrade}
              />
            )}
          </div>
        </div>
      </div>

      {/* Trade Form Modal */}
      {showTradeForm && selectedFolderId && (
        <TradeEntryForm
          trade={editingTrade}
          folderId={selectedFolderId}
          onSave={handleSaveTrade}
          onClose={() => {
            setShowTradeForm(false);
            setEditingTrade(undefined);
          }}
        />
      )}
    </div>
  );
}
