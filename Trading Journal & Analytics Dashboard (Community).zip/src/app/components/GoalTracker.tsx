import { useState } from 'react';
import { Goal } from '../types/trading';
import { Target, Plus, Trash2, X } from 'lucide-react';

interface GoalTrackerProps {
  goals: Goal[];
  folderId: string;
  currentPnL: number;
  onAddGoal: (goal: Omit<Goal, 'id' | 'createdAt'>) => void;
  onDeleteGoal: (id: string) => void;
}

export function GoalTracker({ goals, folderId, currentPnL, onAddGoal, onDeleteGoal }: GoalTrackerProps) {
  const [showForm, setShowForm] = useState(false);
  const [goalForm, setGoalForm] = useState({
    type: 'monthly' as Goal['type'],
    value: 0,
    period: new Date().toISOString().slice(0, 7),
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onAddGoal({
      folderId,
      type: goalForm.type,
      value: goalForm.value,
      current: 0,
      period: goalForm.period,
    });
    setShowForm(false);
    setGoalForm({
      type: 'monthly',
      value: 0,
      period: new Date().toISOString().slice(0, 7),
    });
  };

  return (
    <div className="bg-gray-800 rounded-lg p-4">
      <div className="flex items-center justify-between mb-4">
        <h3 className="font-semibold text-white flex items-center gap-2">
          <Target className="w-5 h-5" />
          Goals & Targets
        </h3>
        <button
          onClick={() => setShowForm(!showForm)}
          className="p-1 hover:bg-gray-700 rounded"
        >
          {showForm ? <X className="w-5 h-5 text-gray-400" /> : <Plus className="w-5 h-5 text-gray-400" />}
        </button>
      </div>

      {showForm && (
        <form onSubmit={handleSubmit} className="mb-4 p-3 bg-gray-900 rounded">
          <div className="grid grid-cols-2 gap-3 mb-3">
            <div>
              <label className="block text-xs text-gray-400 mb-1">Goal Type</label>
              <select
                value={goalForm.type}
                onChange={(e) => setGoalForm({ ...goalForm, type: e.target.value as Goal['type'] })}
                className="w-full px-2 py-1 bg-gray-800 text-white rounded text-sm"
              >
                <option value="monthly">Monthly Target</option>
                <option value="daily">Daily Target</option>
                <option value="trade-limit">Trade Limit</option>
                <option value="max-loss">Max Loss Limit</option>
              </select>
            </div>
            <div>
              <label className="block text-xs text-gray-400 mb-1">
                {goalForm.type === 'trade-limit' ? 'Number of Trades' : 'Amount (₹)'}
              </label>
              <input
                type="number"
                value={goalForm.value}
                onChange={(e) => setGoalForm({ ...goalForm, value: Number(e.target.value) })}
                className="w-full px-2 py-1 bg-gray-800 text-white rounded text-sm"
                required
              />
            </div>
          </div>
          {(goalForm.type === 'monthly' || goalForm.type === 'daily') && (
            <div className="mb-3">
              <label className="block text-xs text-gray-400 mb-1">Period</label>
              <input
                type={goalForm.type === 'monthly' ? 'month' : 'date'}
                value={goalForm.period}
                onChange={(e) => setGoalForm({ ...goalForm, period: e.target.value })}
                className="w-full px-2 py-1 bg-gray-800 text-white rounded text-sm"
              />
            </div>
          )}
          <button
            type="submit"
            className="w-full px-3 py-1 bg-blue-600 text-white rounded text-sm hover:bg-blue-700"
          >
            Add Goal
          </button>
        </form>
      )}

      <div className="space-y-3">
        {goals.length === 0 ? (
          <div className="text-center text-gray-500 text-sm py-4">
            No goals set yet
          </div>
        ) : (
          goals.map((goal) => {
            const progress = goal.value > 0 ? (goal.current / goal.value) * 100 : 0;
            const isExceeded = goal.current > goal.value;
            
            return (
              <div key={goal.id} className="bg-gray-900 p-3 rounded">
                <div className="flex items-center justify-between mb-2">
                  <div>
                    <div className="text-sm text-white">
                      {goal.type === 'monthly' && 'Monthly Target'}
                      {goal.type === 'daily' && 'Daily Target'}
                      {goal.type === 'trade-limit' && 'Trade Limit'}
                      {goal.type === 'max-loss' && 'Max Loss Limit'}
                    </div>
                    <div className="text-xs text-gray-400">{goal.period}</div>
                  </div>
                  <button
                    onClick={() => onDeleteGoal(goal.id)}
                    className="p-1 hover:bg-gray-800 rounded"
                  >
                    <Trash2 className="w-4 h-4 text-gray-500" />
                  </button>
                </div>
                
                <div className="mb-2">
                  <div className="flex justify-between text-xs mb-1">
                    <span className="text-gray-400">
                      {goal.type === 'trade-limit' ? 'Trades' : 'Amount'}
                    </span>
                    <span className={isExceeded ? 'text-red-400' : 'text-gray-400'}>
                      {goal.type === 'trade-limit' ? goal.current : `₹${goal.current.toFixed(2)}`} / {goal.type === 'trade-limit' ? goal.value : `₹${goal.value}`}
                    </span>
                  </div>
                  <div className="w-full bg-gray-700 rounded-full h-2 overflow-hidden">
                    <div
                      className={`h-full transition-all ${
                        isExceeded ? 'bg-red-500' : progress >= 90 ? 'bg-green-500' : 'bg-blue-500'
                      }`}
                      style={{ width: `${Math.min(progress, 100)}%` }}
                    />
                  </div>
                </div>
                
                {progress >= 90 && !isExceeded && (
                  <div className="text-xs text-green-400">🎯 Almost there!</div>
                )}
                {isExceeded && (
                  <div className="text-xs text-red-400">⚠️ Limit exceeded!</div>
                )}
              </div>
            );
          })
        )}
      </div>
    </div>
  );
}
