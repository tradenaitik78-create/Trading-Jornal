export interface Trade {
  id: string;
  folderId: string;
  
  // Basic fields
  tradeType: 'long' | 'short';
  entryDate: string;
  entryTime: string;
  exitDate?: string;
  exitTime?: string;
  symbol: string;
  entryPrice: number;
  exitPrice?: number;
  quantity: number;
  stopLoss?: number;
  target?: number;
  
  // Advanced fields
  screenshots?: string[];
  marketCondition?: 'trending' | 'ranging' | 'volatile';
  timeframe?: string;
  strategyTag?: string;
  emotionBefore?: 'fear' | 'greed' | 'confident' | 'neutral';
  setupQuality?: number; // 1-10
  positionSizePercent?: number;
  
  // Journal
  preTradePlan?: string;
  tradeReasoning?: string;
  postTradeReview?: string;
  lessonsLearned?: string;
  mistakes?: string;
  
  // Calculated
  pnl?: number;
  riskRewardRatio?: number;
  
  createdAt: string;
  updatedAt: string;
}

export interface Folder {
  id: string;
  name: string;
  color: string;
  description?: string;
  tags?: string[];
  createdAt: string;
  initialCapital: number;
}

export interface Goal {
  id: string;
  folderId: string;
  type: 'monthly' | 'daily' | 'trade-limit' | 'max-loss';
  value: number;
  current: number;
  period: string;
  createdAt: string;
}

export interface Analytics {
  totalTrades: number;
  winRate: number;
  totalPnL: number;
  bestTrade: number;
  worstTrade: number;
  avgWin: number;
  avgLoss: number;
  profitFactor: number;
  expectancy: number;
  maxConsecutiveWins: number;
  maxConsecutiveLosses: number;
  maxDrawdown: number;
  sharpeRatio: number;
  currentStreak: number;
  roi: number;
}
