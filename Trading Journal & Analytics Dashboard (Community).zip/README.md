
  # Trading Journal & Analytics Dashboard (Community)

  This is a code bundle for Trading Journal & Analytics Dashboard (Community). The original project is available at https://www.figma.com/design/sapAW2EFBmi41YS2LjKKhY/Trading-Journal---Analytics-Dashboard--Community-.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  